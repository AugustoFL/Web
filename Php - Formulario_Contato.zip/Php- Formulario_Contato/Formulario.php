<!DOCTYPE hmtl>
<html>
    <head> <title> Formulario de Contato</title></head>
<style>
form {
    max-width: 500px;
    margin:0 auto;
    padding: 20px;
    border: 1px solid #ddd;
    border-radius: 5px;
    background-color: #f9f9f9;
}

label {
    display: block;
    font-size: 16px;
    font-weight: bold;
    margin-bottom: 10px;
}

input[type="text"],
input[type="email"]{
    width:100%;
    padding: 10px;
    margin-bottom: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
    box-sizzing: border-box;
    font-size: 16px;
    color: #555;
}

input[type="password"],
input[type="senha"]{
    width: 100px;
    padding: 10px;
    margin-bottom: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
    box-sizing: border-box;
    font-size: 16;
    color: #555;
}

input[type="submit"]{
    background-color: #00acee;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}
input[type="submit"]:hover{
    background-color: #ADD8E6;
}
</style>
<body>

<?php

//verifica se o formulario foi enviado
if (isset($_POST['submit'])){
    //recupera os valores do formulario
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    //monta a mensagem de email
    $mensagem = "Nome: $nome\n";
    $mensagem = "Email: $email\n";
    $mensagem = "Senha: $senha\n";

    //Envia o e-mail
    mail('alexandre.tojeiro@gmail.com', 'Mensagem do formulario de contato', $mensagem);
    //Exibe a mensagem de confirmação
    echo "Obrigado pelo seu contato! Sua mensagem foi enviada.";
}
?>

<center>
    <h2> Formulario de Contato</h2>
    <figure>
        <img src="Logoetec.png" alt=" ">
        <figcaption> <h2> Etec</h2></figcaption>
    </figure>
</center>

<form method="post" action="">
    <label for="nome"> Nome: </laber>
    <input type="text" id="nome" name="nome" required>

    <label for="email"> Email: </label>
    <input type="email" id="email" name="email" required>

    <label for="senha"> Senha: </label>
    <input type="password" id="senha" name="senha" required>

    <input type="submit" name="submit" value="Enviar">
</form>
<center>
    <figure>
        <img src="cadeado.png" alt="">
        <figcaption> <h2> Site Protegido </h2> </figcaption>
</figure>
</center>
 </html>