<?php

$true = true;
$false = false;
$true2 = true;

if ($true xor $true2) {
    echo "Verdadeiro";
}
else {

    //Resultado é falso pois os ambos valores das variaveis verdadeiras
    echo "Falso";
}
?> 