<?php

$num = 10;
//Receber o modulo de 10/5
$num %= 5;

echo "O valor de num é:$num"

?> 