<?php

$nome = "Jacinto";
$sobrenome = "Ferreira de Sá";

echo "<h2>Meu nome é: ".$nome." ".$sobrenome."</h2>";

$end = "Av. Antônio Almeida Leite";
$n = 913;
$endCompleto = $end. ", ".$n;

echo "<h2> Endereço: ". $endCompleto. "</h2>";

$al = "Augusto";
$alsobrenome = "Farias de Lima";
$alsala = "2°DS - AMS";
$alCompleto = $al. " ".$alsobrenome. ". <br>Estuda em: ".$alsala;

echo "<h2> Aluno: ".$alCompleto;
?> 