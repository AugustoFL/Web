<?php

$num = 10;
//Atribuir 10*5 
$num *= 5;

echo "O valor de num é: $num"

?> 