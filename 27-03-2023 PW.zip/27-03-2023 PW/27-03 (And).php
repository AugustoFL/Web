<?php

$true = true;
$false = false;
$true2 = true;

if ($true and $false) {
    echo "Verdadeiro";
}
else {
    //Resultado é falso pois os valores das variaveis são diferentes
    echo "Falso";
}
?> 