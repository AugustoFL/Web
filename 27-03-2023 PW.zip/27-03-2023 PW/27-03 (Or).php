<?php

$true = true;
$false = false;
$true2 = true;

if ($true or $false) {
    //Resultado é falso pois os valores das variaveis são OU verdadeiras, ou falsas
    echo "Verdadeiro";
}
else {
    echo "Falso";
}
?> 