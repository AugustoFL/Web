<?php

$minhaMatriz = [
    [10,26],
    ["Regiane","Vera"],
    ["Prof(a)","da","Etec"]
];

//Quero acessar o valor 26 do primeiro array
//Como posso fazer isso?
//Simples!
echo $minhaMatriz[0][0];
//O primeiro 0 significa que eu quero acessar o primeiro array da matriz
//E o segundo número [1] significa que eu quero acessar o segundo elemento
// do primeiro array

echo "<br>"; //Quebra de linha
echo $minhaMatriz[1][0];
//Neste outro caso, eu estou acessando o último elemento do último array

?>