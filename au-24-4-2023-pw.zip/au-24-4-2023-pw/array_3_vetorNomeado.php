<?php

$meuarray = [
    "nome" => "Etec",
    "rua" => "Av.Antônio de Almeida Leite",
    "numero" => "913",
    "bairro" => "Jd. Paulista",
    "cidade" => "Ourinhos-SP"
];

    echo $meuarray["nome"]; //Pega o primeiro valor
    echo "
    ";
    echo $meuarray["bairro"]; //Pego o segundo valor
    echo "
    ";
    echo $meuarray["cidade"]; //Ultimo Valor
    
?>