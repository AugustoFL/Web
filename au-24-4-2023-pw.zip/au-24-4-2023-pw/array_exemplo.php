<?php

    $meuarray = ["Maria", "Jose", "Carlos", "Ana"];
    //Para exibir um array por completo, usamos o comando vardump
    var_dump($meuarray);
    
?>