<?php

    $meuarray = ["Maria", "Jose", "Carlos", "Ana"];
    //Para exibir um array por completo, usamos o comando vardump
    echo $meuarray[0]; //Pega o primeiro valor
    echo"
    ";
    echo $meuarray[1]; //Pega o segundo valor
    echo"
    ";
    echo $meuarray[2];

?>