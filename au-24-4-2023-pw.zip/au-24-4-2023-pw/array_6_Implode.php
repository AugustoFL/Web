<?php

$arrayDeTexto=["A","ETEC","net","é","a","melhor!"];
    $frase = implode(" ", $arrayDeTexto);
    //Neste caso, eu quero adicionar um caracter de espaço (" ")
    echo $frase;

?>