<?php


$frase = "A etec é a melhor!";
$arrayDeTexto = explode(" ", $frase);

var_dump($arrayDeTexto)

?>